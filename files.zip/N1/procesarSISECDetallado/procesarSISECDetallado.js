function procesarSISECDetallado(patronActual, movimientos, fechaBajaGeneral, vigente) {
    let periodos = [];
    let fechaBajaFinal = fechaBajaGeneral;

    if (!fechaBajaFinal) {
        let bajaMovimiento = movimientos.find((mov) => mov.tipo === "BAJA");
        if (bajaMovimiento) fechaBajaFinal = bajaMovimiento.fecha;
    }

    let movimientosValidos = movimientos.filter((mov) => mov.tipo !== "BAJA");

    if (movimientosValidos.length === 0) {
        Logger.log("⚠️ No se encontraron movimientos válidos para " + patronActual);
        return [];
    }

    for (let i = 0; i < movimientosValidos.length; i++) {
        let fechaAlta =
            i === 0 ? movimientosValidos[i].fecha : restarUnDia(movimientosValidos[i - 1].fecha);
        let salario = movimientosValidos[i].salario;
        let fechaBaja =
            i === 0 ? fechaBajaFinal : restarUnDia(movimientosValidos[i - 1].fecha);

        periodos.push({
            patron: i === 0 ? patronActual : "",
            alta: fechaAlta,
            baja: fechaBaja,
            salario: salario,
            detallado: true,
        });
    }

    Logger.log("📄 Periodos generados para " + patronActual + ": " + JSON.stringify(periodos));
    return periodos;
}